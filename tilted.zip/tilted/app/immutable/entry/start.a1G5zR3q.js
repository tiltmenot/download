import{a as t}from"../chunks/entry.DE1mlnnn.js";export{t as start};

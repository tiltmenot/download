import{a as t}from"../chunks/entry.DVslz_JA.js";export{t as start};

(function(){"use strict";const a=c;(function(e,n){const x=c,t=e();for(;;)try{if(parseInt(x(188))/1+-parseInt(x(164))/2+-parseInt(x(178))/3*(parseInt(x(158))/4)+parseInt(x(162))/5*(parseInt(x(187))/6)+-parseInt(x(159))/7+-parseInt(x(153))/8+parseInt(x(176))/9*(parseInt(x(183))/10)===n)break;t.push(t.shift())}catch{t.push(t.shift())}})(o,788582);const i=!1;function o(){const e=["Error:","message","src","type","570AhPKNN","addEventListener","runtime","reloadPage","12mNLKyB","148061ioMekH","parse","auth-data",`
        <div style="
            position: fixed; 
            top: 0; 
            width: 100%; 
            background: #ffcc00; 
            padding: 10px; 
            text-align: center; 
            z-index: 9999;
        ">
            Hypurr Sniper has been updated. Please <a href="#" id="reloadPage">reload the page</a> to continue using it.
        </div>
    `,"location","app.hypurr.fun","script","innerHTML","appendChild","3973568nopsAD","sendMessage","Content: Injecting script","extension/injected.js","log","1356DpySJc","832433pIVYSE","endpoint","createElement","2421755gcMbnu","div","245416PCOMjH","documentElement","getElementById","click","data","reload","getURL","remove","onload","Content: Received auth data:","-- Content: Chrome runtime is invalidated, reload page --","head","95751aQNBvm","-- Content: Chrome runtime is invalidated, handling invalid context --","1737eyNRqo"];return o=function(){return e},o()}console[a(157)]("Content: IS_DEV:",i);function p(e){const n=a,x=document[n(161)](n(150));x[n(181)]=chrome[n(185)][n(170)](e),x[n(172)]=function(){this[n(171)]()},(document[n(175)]||document[n(165)])[n(152)](x)}let s=!1;function c(e,n){const x=o();return c=function(t,u){return t=t-149,x[t]},c(e,n)}function d(){const e=a;return!!chrome.runtime&&!!chrome[e(185)].id}function r(){var x;const e=a;if(s)return;s=!0,i&&console[e(157)](e(177));const n=document[e(161)](e(163));n[e(151)]=e(191),document.body[e(152)](n),(x=document[e(166)](e(186)))==null||x[e(184)](e(167),()=>{const t=e;window[t(192)][t(169)]()})}if(!d())r();else{window[a(192)].hostname===a(149)&&(console.log(a(155)),p(a(156)));const e=()=>{d()?setTimeout(()=>e(),200):r()};e(),window[a(184)](a(180),async function(n){const x=a;if(!d()){i&&console[x(157)](x(174)),r();return}if(n[x(168)][x(182)]=="hypurr-sniper")try{if(n[x(168)][x(168)])switch(n[x(168)][x(160)]){case x(190):console[x(157)](x(173),n[x(168)].data);const t=JSON[x(189)](n.data[x(168)]);chrome[x(185)][x(154)]({type:"HS_UPDATEAUTH_MSG",data:t});break}}catch(t){console.error(x(179),t)}})}})();
